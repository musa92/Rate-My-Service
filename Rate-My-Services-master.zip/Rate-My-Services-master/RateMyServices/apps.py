from django.apps import AppConfig


class RatemyservicesConfig(AppConfig):
    name = 'RateMyServices'
